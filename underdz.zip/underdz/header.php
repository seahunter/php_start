<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package underdz
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php 
    $menu = wp_get_nav_menu_items('menu-1');
    $logo = get_field('logo', 'option');
    $facebook = get_field('facebook', 'option');
    $instagram = get_field('instagram', 'option');
    $phone = get_field('tel', 'option');
    $email = get_field('e-mail', 'option');
?>
<header class="header">
    <div class="header__container container">
        <div class="header__wrapper">
            <div class="header__logo">
                <div class="logo"><img class="logo__img" src="<?php echo $logo['sizes']['thumbnail'] ?>" alt="" role="presentation" />
                </div>
            </div>
            <div class="header__language">
                <div class="language js-lang">
                    <div class="language__btn">Ru
                    </div>
                    <div class="language__content"><a href="#">Russian</a><a href="#">English</a><a href="#">Deutsch</a>
                    </div>
                </div>
            </div>
            <div class="header__menu">
                <div class="header__language header__language--mobile">
                    <div class="language js-lang">
                        <div class="language__btn">Ru
                        </div>
                        <div class="language__content"><a href="#">En</a><a href="#">Ba</a>
                        </div>
                    </div>
                </div>
                <?php if( ! empty( $menu ) ) : ?>
                <nav class="header__nav header__nav--mobile">
                    <ul class="nav js-mob-menu">
                        <?php foreach ($menu as $item): ?>
                            <li class="nav__item"><a class="nav__link" href="<?php echo $item->url ?>"><?php echo $item->title ?></a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </nav>
                <nav class="header__nav">
                    <ul class="nav">
                        <?php foreach ($menu as $item): ?>
                            <li class="nav__item"><a class="nav__link" href="<?php echo $item->url ?>"><?php echo $item->title ?></a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </nav>
                <?php endif ?>
                <div class="header__social header__social--mobile">
                    <div class="social">
                        <a class="social__item" href="<?php echo $facebook ?>" target="_blank"><span class="social__icon icon-facebook"></span></a>
                        <a class="social__item" href="<?php echo $instagram ?>" target="_blank"><span class="social__icon icon-instagram"></span></a>
                    </div>
                </div>
                <div class="header__search header__search--mobile">
                    <div class="search js-search"><span class="search__icon icon-search"></span><span class="search__icon icon-close is-hide"></span>
                        <form class="search__field search__field--mobile"><input class="search__input" placeholder="Search" type="text" />
                            <button class="search__btn">Поиск
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="header__social">
                <div class="social">
                    <a class="social__item" href="<?php echo $facebook ?>" target="_blank"><span class="social__icon icon-facebook"></span></a>
                    <a class="social__item" href="<?php echo $instagram ?>" target="_blank"><span class="social__icon icon-instagram"></span></a>
                </div>
            </div>
            <div class="header__search">
                <div class="search js-search"><span class="search__icon icon-search"></span><span class="search__icon icon-close is-hide"></span>
                    <form class="search__field"><input class="search__input" placeholder="Search" type="text" />
                        <button class="search__btn">Поиск
                        </button>
                    </form>
                </div>
            </div>
            <div class="header__info">
                <a class="header__telephone" href="tel:<?php echo $phone ?>"><?php echo $phone ?></a>
                <a class="header__email" href="mailto:<?php echo $email ?>"><?php echo $email ?></a>
            </div>
            <div class="header__mobile-btn">
                <div class="mobile-btn"><span class="mobile-btn__line"></span><span class="mobile-btn__line"></span><span class="mobile-btn__line"></span>
                </div>
            </div>
        </div>
    </div>
</header>