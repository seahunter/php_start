<?php get_header() ?>
    <main class="main" id="main">
    	<?php while( have_posts() ) : the_post() ?>
        <div class="main-slider" style="background-image: url('../static/img/bg-main-slider.jpg')">
            <div class="decor">
                <div class="decor__item decor__item--left"><img class="decor__img" src="../static/img/decor-slider.jpg" alt="" role="presentation" />
                </div>
                <div class="decor__item decor__item--right">
                </div>
            </div>
            <div class="main-slider__container container">
                <div class="main-slider__wrapper main-slider__wrapper--column">
                    <div class="main-slider__item main-slider__item--left-main">
                    	<?php $gallery_big = get_field('gallery_big') ?>
                    	<?php if( ! empty( $gallery_big ) ) : ?>
                        <div class="swiper-container slider-1 prev">
                            <div class="swiper-wrapper">
                            	<?php foreach( $gallery_big as $item ) : ?>
                                <div class="swiper-slide" style="background-image:url(<?php echo $item['sizes']['medium_large'] ?>)"></div>
	                            <?php endforeach ?>
                            </div>
                        </div>
	                    <?php endif ?>
                        <?php $gallery_small = get_field('gallery_small') ?>
                        <?php if( ! empty( $gallery_small ) ) : ?>
                        <div class="swiper-container slider-1">
                            <div class="swiper-wrapper">
				             	<?php foreach( $gallery_small as $item ) : ?>
                                <div class="swiper-slide" style="background-image:url(<?php echo $item['sizes']['medium'] ?>)"></div>
	                            <?php endforeach ?>
                            </div>
                        </div>
                        <?php endif ?>
                        <div class="slider-arrow slider-arrow--mobile">
                            <div class="slider-arrow__next swiper-prev">
                            </div>
                            <div class="slider-arrow__prev swiper-next">
                            </div>
                        </div>
                    </div>
                    <div class="main-slider__item main-slider__item--right-main">
                        <div class="main-slider__info">
                            <div class="main-slider__title">
                                <h1 class="title title--h1 title--line-h1"><?php the_title() ?>
                                </h1>
                            </div>
                            <div class="main-slider__btn-wrapper"><a class="btn" href="#">Что мы предлагаем</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-slider__wrapper main-slider__wrapper--prev-mt">
                <div class="main-slider__item main-slider__item--left-prev">
                </div>
                <div class="main-slider__item main-slider__item--right-prev">
                    <div class="swiper-container slider-2">
                        <?php $gallery_small = get_field('gallery_small') ?>
                        <?php if( ! empty( $gallery_small ) ) : ?>
                        <div class="swiper-wrapper">
                        	<?php foreach ($gallery_small as $key => $value): ?>
	                            <div class="swiper-slide" style="background-image:url(<?php echo $value['sizes']['medium'] ?>)"></div>
                        	<?php endforeach ?>
                        </div>
	                    <?php endif ?>
                    </div>
                    <div class="slider-arrow">
                        <div class="slider-arrow__next swiper-prev">
                        </div>
                        <div class="slider-arrow__prev swiper-next">
                        </div>
                    </div>
                </div>
            </div>
        </div>
	    <?php endwhile ?>
        
        <?php 
            $services_args = array(
                'post_type' => 'uslugi',
                'posts_per_page' => 3,
                'post_status' => 'publish'
            );

            $services = new WP_Query( $services_args );
        ?>
        <?php if( $services->have_posts() ) : ?>
        <div class="services services--margin-bot">
            <div class="services__container container">
                <div class="services__wrapper">
                    <?php $key = 0 ?>
                    <?php while( $services->have_posts() ) : $services->the_post(); ?>
                    <?php 
                        $animation = '';
                        if( $key == 0 || $key % 2 == 0 ) {
                           $animation = 'fadeInLeft'; 
                        } else {
                            $animation = 'fadeInRight';
                        }
                    ?>
                    <div class="services__item js-animate" data-type-animate="<?php echo $animation ?>">
                        <div class="card">
                            <div class="card__wrapper">
                                <div class="card__item card__item--right">
                                    <div class="card__info">
                                        <div class="card__title card__title--mb-services">
                                            <h2 class="title title--h2-thin"><?php the_title() ?><span class="title__index">01</span>
                                            </h2>
                                        </div>
                                        <div class="card__image card__image--mobile">
                                            <img class="card__img" src="<?php echo get_the_post_thumbnail_url( get_the_id(), 'medium_large' ) ?>" alt="" role="presentation" />
                                        </div>
                                        <div class="card__content">
                                            <div class="card__text">
                                                <?php the_content() ?>
                                            </div>
                                            <div class="card__btn-wrapper"><a class="btn btn--arrow-blue" href="<?php the_permalink() ?>">Подробнее</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card__item card__item--left card__item--none">
                                    <div class="card__image"><img class="card__img" src="<?php echo get_the_post_thumbnail_url( get_the_id(), 'medium_large' ) ?>" alt="" role="presentation" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $key = $key + 1 ?>
                    <?php endwhile; wp_reset_postdata() ?>
                </div>
            </div>
        </div>
        <?php endif ?>

        <?php 
            $reviews_args = array(
                'post_type' => 'review',
                'posts_per_page' => 4,
                'post_status' => 'publish'
            );

            $reviews = new WP_Query( $reviews_args );
        ?>
        <?php if( $reviews->have_posts() ) : ?>
        <div class="reviews reviews--mb js-animate" data-type-animate="fadeIn">
            <div class="reviews__container container">
                <div class="reviews__title">
                    <h2 class="title title--h2"> <span>Отзывы </span>о работе нашей компании
                    </h2>
                </div>
            </div>
            <div class="reviews__wrapper">
                <?php $key = 0 ?>
                <?php while( $reviews->have_posts() ) : $reviews->the_post(); ?>
                <div class="reviews__item js-animate-card" data-type-animate="fadeInUp">
                    <div class="card">
                        <div class="card__photo"><img class="card__img" src="<?php echo get_the_post_thumbnail_url() ?>" alt="" role="presentation" />
                        </div>
                        <div class="card__name"><?php the_title() ?>
                        </div>
                        <div class="card__raiting">
                            <?php $stars = get_field('star_counter') ?>
                            <?php for( $i = 0; $i < $stars; $i++ ) : ?>
                                <img class="card__star" src="<?php echo get_theme_file_uri('/static/img/star.png') ?>" alt="" role="presentation" />
                            <?php endfor ?>
                        </div>
                        <div class="card__text card__text--reviews"><?php the_content() ?>
                        </div><a class="card__btn-wrapper" href="<?php the_permalink( ) ?>"><span class="btn btn--blue">Смотреть оригинал</span></a>
                    </div>
                </div>
                <?php endwhile; wp_reset_postdata() ?>
            </div>
        </div>
        <?php endif ?>
    </main>
<?php get_footer() ?>