<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="/static/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="<?php bloginfo('template_directory');?>/static/css/style.css">
    <title>Venit Group</title>
</head>

<body>
    <?php echo get_stylesheet_directory_uri();?>
   
    <header class="header">
        <div class="header__container container">
            <div class="header__wrapper">
                <div class="header__logo"><a class="logo" href="#"><img class="logo__img" src="<?php echo get_stylesheet_directory_uri() ?>/static/img/logo-dark.png" alt="" role="presentation" /></a>
                </div>
                <div class="header__language">
                    <div class="language js-lang">
                        <div class="language__btn">Ru
                        </div>
                        <div class="language__content"><a href="#">Russian</a><a href="#">English</a><a href="#">Deutsch</a>
                        </div>
                    </div>
                </div>
                <div class="header__menu">
                    <div class="header__language header__language--mobile">
                        <div class="language js-lang">
                            <div class="language__btn">Ru
                            </div>
                            <div class="language__content"><a href="#">En</a><a href="#">Ba</a>
                            </div>
                        </div>
                    </div>
                    <nav class="header__nav header__nav--mobile">
                        <ul class="nav js-mob-menu">
                            <li class="nav__item"><a class="nav__link" href="/">Главная</a>
                            </li>
                            <li class="nav__item has-submenu"><a class="nav__link arrow" href="#" data-menu-name="Услуги">Услуги</a>
                                <ul class="nav nav--sub">
                                    <li class="nav__item nav__item--sub"><a class="nav__link" href="#">Первая</a>
                                    </li>
                                    <li class="nav__item nav__item--sub"><a class="nav__link" href="#">Вторая</a>
                                    </li>
                                    <li class="nav__item nav__item--sub"> <a class="nav__link" href="#">Третья </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav__item"><a class="nav__link" href="/gallery.html">Галерея</a>
                            </li>
                            <li class="nav__item"> <a class="nav__link" href="/news.html">Новости</a>
                            </li>
                            <li class="nav__item"> <a class="nav__link" href="/about.html">О нас</a>
                            </li>
                        </ul>
                    </nav>
                    <nav class="header__nav">
                        <ul class="nav">
                            <li class="nav__item"><a class="nav__link" href="/">Главная</a>
                            </li>
                            <li class="nav__item has-submenu"><a class="nav__link arrow" href="/servic.html">Услуги</a>
                                <ul class="nav nav--sub">
                                    <li class="nav__item nav__item--sub"><a class="nav__link" href="#">Первая</a>
                                    </li>
                                    <li class="nav__item nav__item--sub"><a class="nav__link" href="#">Вторая</a>
                                    </li>
                                    <li class="nav__item nav__item--sub"> <a class="nav__link" href="#">Третья </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav__item"><a class="nav__link" href="/gallery.html">Галерея</a>
                            </li>
                            <li class="nav__item"> <a class="nav__link" href="/news.html">Новости</a>
                            </li>
                            <li class="nav__item"> <a class="nav__link" href="/about.html">О нас</a>
                            </li>
                        </ul>
                    </nav>
                    <div class="header__social header__social--mobile">
                        <div class="social"><a class="social__item" href="#" target="_blank"><span class="social__icon icon-facebook"></span></a><a class="social__item" href="#" target="_blank"><span class="social__icon icon-instagram"></span></a>
                        </div>
                    </div>
                    <div class="header__search header__search--mobile">
                        <div class="search js-search"><span class="search__icon icon-search"></span><span class="search__icon icon-close is-hide"></span>
                            <form class="search__field search__field--mobile"><input class="search__input" placeholder="Search" type="text" />
                                <button class="search__btn">Поиск
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="header__social">
                    <div class="social"><a class="social__item" href="#" target="_blank"><span class="social__icon icon-facebook"></span></a><a class="social__item" href="#" target="_blank"><span class="social__icon icon-instagram"></span></a>
                    </div>
                </div>
                <div class="header__search">
                    <div class="search js-search"><span class="search__icon icon-search"></span><span class="search__icon icon-close is-hide"></span>
                        <form class="search__field"><input class="search__input" placeholder="Search" type="text" />
                            <button class="search__btn">Поиск
                            </button>
                        </form>
                    </div>
                </div>
                <div class="header__info"><a class="header__telephone" href="tel:+3804433333333">+38 (044) 333 333 33</a><a class="header__email" href="mailto:example@example.com">example@example.com</a>
                </div>
                <div class="header__mobile-btn">
                    <div class="mobile-btn"><span class="mobile-btn__line"></span><span class="mobile-btn__line"></span><span class="mobile-btn__line"></span>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main class="main" id="main">
        <div class="breadcrumb">
            <div class="breadcrumb__container container">
                <p id="breadcrumbs"><span><span><a href="/">Главная </a><span class="separator">/</span><a href="/gallery.html">Галерея</a><span class="separator">/</span><span class="last">Название альбома</span></span></span></p>
            </div>
        </div>
        <div class="news">
            <div class="news__container container">
                <div class="news__title">
                    <div class="title title--h2">Новости
                    </div>
                </div>
                <div class="news__description templates">
                    <p>Рыбатекст используется дизайнерами, проектировщиками и фронтендерами, когда нужно быстро заполнить макеты или прототипы содержимым. Это тестовый контент, который не должен нести никакого смысла, лишь показать наличие самого текста или продемонстрировать типографику в деле.</p>
                </div>
                <div class="news__wrapper">
                    <div class="news__item news__item--w50">
                        <div class="card-news card-news--main">
                            <div class="card-news__overlay">
                            </div>
                            <div class="card-news__image-wrapper card-news__image-wrapper--main"><img class="card-news__img" src="../static/img/news1.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info card-news__info--main">
                                <div class="card-news__title">
                                    <h4 class="title title--h4 title--white">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link card-news__link--main" href="#">Подробнее</a>
                                <div class="card-news__data card-news__data--main">25 Май 2019
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                    <div class="news__item news__item--w25">
                        <div class="card-news">
                            <div class="card-news__image-wrapper"><img class="card-news__img" src="../static/img/news2.jpg" alt="" role="presentation" />
                            </div>
                            <div class="card-news__info">
                                <div class="card-news__data">25 Май 2019
                                </div>
                                <div class="card-news__title">
                                    <h4 class="title title--h4">Daily Mail показала интерьер самого дорогого особняка Британии
                                    </h4>
                                </div><a class="card-news__link" href="/news-page.html">Подробнее</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pagination">
            <div class="pagination__container container">
                <div class="pagination__wrapper"><a class="pagination__prev pagination__prev--left" href="#">previous</a>
                    <div class="pagination__pages"><a class="pagination__link pagination__link--mob" href="#">1</a><a class="pagination__link" href="#">2</a>
                        <div class="pagination__link pagination__link--gap">...
                        </div><a class="pagination__link" href="#">15</a>
                        <div class="pagination__link is-current">16
                        </div><a class="pagination__link" href="#">17</a>
                        <div class="pagination__link pagination__link--gap">...
                        </div><a class="pagination__link" href="#">26</a><a class="pagination__link pagination__link--mob" href="#">27</a>
                    </div><a class="pagination__next pagination__next--right" href="#">next</a>
                </div>
            </div>
        </div>
    </main>
    <div class="footer">
        <div class="footer__top">
            <div class="container">
                <div class="wrapper wrapper--footer">
                    <div class="wrapper__item wrapper__item--footer-left">
                        <div class="row">
                            <div class="row__elem row__elem--w100">
                                <div class="logo logo--footer"><img class="logo__img" src="<?php echo get_stylesheet_directory_uri() ?>/static/img/logo-white.png" alt="" role="presentation" />
                                </div>
                            </div>
                            <div class="row__elem">
                                <div class="title title--h4 title--white js-dropdown-footer">О компании
                                </div>
                                <ul class="list is-hide">
                                    <li class="list__item"><a class="link link--footer" href="#">Партнеры</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="/about.html">О нас</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Контакты</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="/news.html">Новости</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="row__elem">
                                <div class="title title--h4 title--white js-dropdown-footer">Услуги
                                </div>
                                <ul class="list is-hide">
                                    <li class="list__item"><a class="link link--footer" href="#">Дизайн интерьеров</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Ремонт квартир</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Строительство коттеджей</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="row__elem">
                                <div class="title title--h4 title--white js-dropdown-footer">Галерея
                                </div>
                                <ul class="list is-hide">
                                    <li class="list__item"><a class="link link--footer" href="#">Дизайн</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Квартиры</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Строительство</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="wrapper__item wrapper__item--footer-right">
                        <div class="title title--h4 title--white">Наши контакты:
                        </div>
                        <div class="contacts">
                            <div class="contacts__phone"><a href="tel:+3800506789900">050 678 99 00</a><a href="tel:+3800506789900">050 678 99 00</a>
                            </div>
                            <div class="contacts__email"><a href="mailto:example@example.com">example@example.com</a>
                            </div>
                            <div class="contacts__address">Адрес: 00000 г. Киев, ул. Киевская, 00, офис 43
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer__bottom">
            <div class="footer__container container">
                <div class="wrapper">
                    <div class="wrapper__item wrapper__item--footer-bottom-left">
                        <div class="copyright">© copyright 2019
                        </div>
                        <div class="social"><a class="social__item social__item--footer" href="#" target="_blank">facebook<span class="social__icon social__icon--footer icon-facebook"></span></a><a class="social__item social__item--footer" href="#" target="_blank">instagram<span class="social__icon social__icon--footer icon-instagram"></span></a>
                        </div>
                    </div>
                    <div class="wrapper__item wrapper__item--footer-bottom-right">
                        <div class="developer">Разработка сайта студия <a href="#">WebCase</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="js-ajax-popup"></div>
    <script src="/static/js/vendor.js"></script>
    <script src="/static/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/goodshare.js@6/goodshare.min.js"></script>
</body>

</html>