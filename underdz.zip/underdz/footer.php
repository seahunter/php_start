<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package underdz
 */

?>

<!-- <div class="footer">
    <div class="footer__top">
        <div class="container">
            <div class="wrapper wrapper--footer">
                <div class="wrapper__item wrapper__item--footer-left">
                    <div class="row">
                        <div class="row__elem row__elem--w100">
                            <div class="logo logo--footer"><img class="logo__img" src="../static/img/logo-white.png" alt="" role="presentation" />
                            </div>
                        </div>
                        <div class="row__elem">
                            <div class="title title--h4 title--white js-dropdown-footer">О компании
                            </div>
                            <ul class="list is-hide">
                                <li class="list__item"><a class="link link--footer" href="#">Партнеры</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="/about.html">О нас</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="#">Контакты</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="/news.html">Новости</a>
                                </li>
                            </ul>
                        </div>
                        <div class="row__elem">
                            <div class="title title--h4 title--white js-dropdown-footer">Услуги
                            </div>
                            <ul class="list is-hide">
                                <li class="list__item"><a class="link link--footer" href="#">Дизайн интерьеров</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="#">Ремонт квартир</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="#">Строительство коттеджей</a>
                                </li>
                            </ul>
                        </div>
                        <div class="row__elem">
                            <div class="title title--h4 title--white js-dropdown-footer">Галерея
                            </div>
                            <ul class="list is-hide">
                                <li class="list__item"><a class="link link--footer" href="#">Дизайн</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="#">Квартиры</a>
                                </li>
                                <li class="list__item"><a class="link link--footer" href="#">Строительство</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="wrapper__item wrapper__item--footer-right">
                    <div class="title title--h4 title--white">Наши контакты:
                    </div>
                    <div class="contacts">
                        <div class="contacts__phone"><a href="tel:+3800506789900">050 678 99 00</a><a href="tel:+3800506789900">050 678 99 00</a>
                        </div>
                        <div class="contacts__email"><a href="mailto:example@example.com">example@example.com</a>
                        </div>
                        <div class="contacts__address">Адрес: 00000 г. Киев, ул. Киевская, 00, офис 43
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__bottom">
        <div class="footer__container container">
            <div class="wrapper">
                <div class="wrapper__item wrapper__item--footer-bottom-left">
                    <div class="copyright">© copyright 2019
                    </div>
                    <div class="social"><a class="social__item social__item--footer" href="#" target="_blank">facebook<span class="social__icon social__icon--footer icon-facebook"></span></a><a class="social__item social__item--footer" href="#" target="_blank">instagram<span class="social__icon social__icon--footer icon-instagram"></span></a>
                    </div>
                </div>
                <div class="wrapper__item wrapper__item--footer-bottom-right">
                    <div class="developer">Разработка сайта студия <a href="#">WebCase</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 -->

 <!---------------------------------------------------------------->
 <?php 
 $menu_left = wp_get_nav_menu_items('menu-footer-left');
  $logoniz = get_field('logo-white', 'option');
  $menu_center=wp_get_nav_menu_items('menu-footer-center');
  $menu=wp_get_nav_menu_items('menu-footer');
    $facebook = get_field('facebook', 'option');
    $instagram = get_field('instagram', 'option');
    $phone = get_field('tel', 'option');
    $email = get_field('e-mail', 'option');
    $contacts=get_field('adress','option');
 ?>
   <div class="footer">
        <div class="footer__top">
            <div class="container">
                <div class="wrapper wrapper--footer">
                    <div class="wrapper__item wrapper__item--footer-left">
                        <div class="row">
                            <div class="row__elem row__elem--w100">
                                <div class="logo logo--footer"><img class="logo__img" src="<?php echo $logoniz['sizes']['thumbnail'] ?>" alt="" role="presentation" />
                                </div>
                            </div>
                            <div class="row__elem">
                              <!----------------------------------------->
                                     <ul class="nav">
                        <?php foreach ($menu as $item): ?>
                            <li class="title title--h4 title--white js-dropdown-footer"><a href="<?php echo $item->url ?>"><?php echo $item->title ?></a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                              <!----------------------------------------->
                                <div class="title title--h4 title--white js-dropdown-footer">О компании
                                </div>
                            
                                <ul class="list is-hide">
                                    
                                    <?php foreach ($menu_left as $item): ?>

                                    <!-- Кусок кода заменяется циклом -->

                                    <!-- <li class="list__item"><a class="link link--footer" href="#">Партнеры</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="/about.html">О нас</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Контакты</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="/news.html">Новости</a>
                                    </li>-->
                                    <li class="list__item"><a class = "link link--footer" href=<?php echo $item->url ?>"><?php echo $item->title ?></a>
                                <?php endforeach ?>
                                </ul>
                            </div>
                            <div class="row__elem">
                                <div class="title title--h4 title--white js-dropdown-footer">Услуги
                                </div>
                                <ul class="list is-hide"></ul>
                                <ul>
                                    <?php foreach ($menu_center as $item): ?>
                                         <li class="list__item"><a class = "link link--footer" href=<?php echo $item->url ?>"><?php echo $item->title ?></a>
                                    <?php endforeach ?>

                                                 
                                </ul>
                            </div>
                            <div class="row__elem">
                                <div class="title title--h4 title--white js-dropdown-footer">Галерея
                                </div>
                                <ul class="list is-hide">
                                    <li class="list__item"><a class="link link--footer" href="#">Дизайн</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Квартиры</a>
                                    </li>
                                    <li class="list__item"><a class="link link--footer" href="#">Строительство</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="wrapper__item wrapper__item--footer-right">
                        <div class="title title--h4 title--white">Наши контакты:
                        </div>
                        <div class="contacts">
                            <div class="contacts__phone"><a href="tel:<?php echo $phone ?>"><?php echo $phone ?></a>
                         <!--   <div class="contacts__phone"><a href="tel:+3800506789900">050 678 99 00</a><a href="tel:+3800506789900">050 678 99 00</a>-->
                            </div>
                           
               <!-- <div class="contacts__email"><a href="mailto:example@example.com">example@example.com</a>-->
 <!--<div class="contacts__phone"><a href="mailto:<?php echo $email ?>"><?php echo $email ?></a>-->


                            </div>
                           <div class="contacts__address"><?php echo $email ?></a></div>
                            <div class="contacts__address"><?php echo $contacts ?></a>
<!--Адрес: 00000 г. Киев, ул. Киевская, 00, офис 43/a>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer__bottom">
            <div class="footer__container container">
                <div class="wrapper">
                    <div class="wrapper__item wrapper__item--footer-bottom-left">
                        <div class="copyright">© copyright 2019
                        </div>
                        <div class="social"><a class="social__item social__item--footer" href="#" target="_blank">facebook<span class="social__icon social__icon--footer icon-facebook"></span></a><a class="social__item social__item--footer" href="#" target="_blank">instagram<span class="social__icon social__icon--footer icon-instagram"></span></a>
                        </div>
                    </div>
                    <div class="wrapper__item wrapper__item--footer-bottom-right">
                        <div class="developer">Разработка сайта студия <a href="#">WebCase</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php wp_footer(); ?>

</body>
</html>
